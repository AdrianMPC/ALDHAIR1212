﻿namespace POKEMON.DL.DALC
{
    public class Class1
    {

    }
}