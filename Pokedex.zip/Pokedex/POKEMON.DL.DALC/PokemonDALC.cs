﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POKEMON.BL.BE;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace POKEMON.DL.DALC
{
    public class PokemonDALC
    {
        public List<PokemonBE> PokemonListar()
        {
            try
            {
                String strCadenaConexion = "server=DESKTOP-QCCGD0O\\SQLEXPRESS01; database=POKEDEX; Integrated Security=true;";
                SqlConnection Con = new SqlConnection(strCadenaConexion);
                String strSP = "uspPokemonListar";
                SqlCommand Cmd = new SqlCommand(strSP, Con);
                List<PokemonBE> LstPokemonBE = new List<PokemonBE>();
                Con.Open();
                SqlDataReader reader = Cmd.ExecuteReader();
                    
                while (reader.Read())
                {
                    PokemonBE objPokemon = new PokemonBE();
                    objPokemon.pokemonID = Convert.ToInt32(reader[0]);
                    objPokemon.cod = Convert.ToInt32(reader[1]);
                    objPokemon.nombre = reader[2].ToString();
                    objPokemon.tipo1 = Convert.ToInt32(reader[3]);
                    objPokemon.descripcion = reader[4].ToString();
                    objPokemon.tipo2 = Convert.ToInt32(reader[5]);
                    objPokemon.imagen = reader[6].ToString();
                    objPokemon.altura = Convert.ToDecimal(reader[7]);
                    objPokemon.peso = Convert.ToDecimal(reader[8]);
                    LstPokemonBE.Add(objPokemon);
                }
                reader.Close();

                return LstPokemonBE;
            }
            catch (Exception ex) 
            {
                throw ex;
            }
            return null;
        }

        public bool AgregarPokemon(PokemonBE objPokemon)
        {
            try
            {
                String strCadenaConexion = "server=DESKTOP-QCCGD0O\\SQLEXPRESS01; database=POKEDEX; Integrated Security=true;";
                SqlConnection Con = new SqlConnection(strCadenaConexion);
                String strSP = "uspPokemonAgregar";
              
                SqlCommand Cmd = new SqlCommand(strSP, Con);
                Cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter[] arrSqlParameter = new SqlParameter[8];

                arrSqlParameter[0] = new SqlParameter();
                arrSqlParameter[0].ParameterName = "@codigo";
                arrSqlParameter[0].SqlDbType = SqlDbType.Int;
                arrSqlParameter[0].Value = objPokemon.cod;

                arrSqlParameter[1] = new SqlParameter();
                arrSqlParameter[1].ParameterName = "@nombre";
                arrSqlParameter[1].SqlDbType = SqlDbType.VarChar;
                arrSqlParameter[1].Size = 30;
                arrSqlParameter[1].Value = objPokemon.nombre;

                arrSqlParameter[2] = new SqlParameter();
                arrSqlParameter[2].ParameterName = "@IDTipo1";
                arrSqlParameter[2].SqlDbType = SqlDbType.Int;
                arrSqlParameter[2].Value = objPokemon.tipo1;

                arrSqlParameter[3] = new SqlParameter();
                arrSqlParameter[3].ParameterName = "@descripcion";
                arrSqlParameter[3].SqlDbType = SqlDbType.VarChar;
                arrSqlParameter[3].Size = 200;
                arrSqlParameter[3].Value = objPokemon.descripcion;

                arrSqlParameter[4] = new SqlParameter();
                arrSqlParameter[4].ParameterName = "@IDTipo2";
                arrSqlParameter[4].SqlDbType = SqlDbType.Int;
                arrSqlParameter[4].Value = objPokemon.tipo2;

                arrSqlParameter[5] = new SqlParameter();
                arrSqlParameter[5].ParameterName = "@Imagen";
                arrSqlParameter[5].SqlDbType = SqlDbType.VarChar;
                arrSqlParameter[5].Size = 150;
                arrSqlParameter[5].Value = objPokemon.imagen;

                arrSqlParameter[6] = new SqlParameter();
                arrSqlParameter[6].ParameterName = "@altura";
                arrSqlParameter[6].SqlDbType = SqlDbType.Decimal;
                arrSqlParameter[6].Precision =4;
                arrSqlParameter[6].Value = objPokemon.altura;
				
				arrSqlParameter[7] = new SqlParameter();
                arrSqlParameter[7].ParameterName = "@peso";
                arrSqlParameter[7].SqlDbType = SqlDbType.Decimal;
                arrSqlParameter[7].Precision =10;
                arrSqlParameter[7].Value = objPokemon.peso;

                 Cmd.Parameters.AddRange(arrSqlParameter);
                Con.Open();
                Cmd.ExecuteNonQuery();
                Con.Close();
                return true;

            }
            catch(Exception ex)
            {
                return false;
            }
        }
		
		 public PokemonBE PokemonObtener(int id)
        {
            try
            {
				String strCadenaConexion = "server=DESKTOP-QCCGD0O\\SQLEXPRESS01; database=POKEDEX; Integrated Security=true;";
                SqlConnection Con = new SqlConnection(strCadenaConexion);
                String strSP = "uspPokemonObtener";
                SqlCommand Cmd = new SqlCommand(strSP, Con);

                Cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter arrSqlParameter = new SqlParameter();

                arrSqlParameter.ParameterName = "@codigo";
                arrSqlParameter.SqlDbType = SqlDbType.Int;
                arrSqlParameter.Value = id;

                PokemonBE objPokemon = new PokemonBE();
                Con.Open();
                Cmd.Parameters.Add(arrSqlParameter);
                Cmd.ExecuteNonQuery();

                SqlDataReader reader = Cmd.ExecuteReader();
                while (reader.Read())
                {
                    objPokemon.pokemonID = Convert.ToInt32(reader[0]);
                    objPokemon.cod = Convert.ToInt32(reader[1]);
                    objPokemon.nombre = reader[2].ToString();
                    objPokemon.tipo1 = Convert.ToInt32(reader[3]);
                    objPokemon.descripcion = reader[4].ToString();
                    objPokemon.tipo2 = Convert.ToInt32(reader[5]);
                    objPokemon.imagen = reader[6].ToString();
                    objPokemon.altura = Convert.ToDecimal(reader[7]);
                    objPokemon.peso = Convert.ToDecimal(reader[8]);

                }
                Con.Close();

                return objPokemon;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		
		 public bool PokemonEditar(PokemonBE objPokemon)
        {
            try
            {
                String strCadenaConexion = "server=DESKTOP-QCCGD0O\\SQLEXPRESS01; database=POKEDEX; Integrated Security=true;";
                SqlConnection Con = new SqlConnection(strCadenaConexion);
                String strSP = "uspPokemonEditar";
                SqlCommand Cmd = new SqlCommand(strSP, Con);
                Cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter[] arrSqlParameter = new SqlParameter[9];
				
				arrSqlParameter[0] = new SqlParameter();
                arrSqlParameter[0].ParameterName = "@pokemonID";
                arrSqlParameter[0].SqlDbType = SqlDbType.Int;
                arrSqlParameter[0].Value = objPokemon.pokemonID;

                arrSqlParameter[1] = new SqlParameter();
                arrSqlParameter[1].ParameterName = "@codigo";
                arrSqlParameter[1].SqlDbType = SqlDbType.Int;
                arrSqlParameter[1].Value = objPokemon.cod;

                arrSqlParameter[2] = new SqlParameter();
                arrSqlParameter[2].ParameterName = "@nombre";
                arrSqlParameter[2].SqlDbType = SqlDbType.VarChar;
                arrSqlParameter[2].Size = 30;
                arrSqlParameter[2].Value = objPokemon.nombre;

                arrSqlParameter[3] = new SqlParameter();
                arrSqlParameter[3].ParameterName = "@IDTipo1";
                arrSqlParameter[3].SqlDbType = SqlDbType.Int;
                arrSqlParameter[3].Value = objPokemon.tipo1;

                arrSqlParameter[4] = new SqlParameter();
                arrSqlParameter[4].ParameterName = "@descripcion";
                arrSqlParameter[4].SqlDbType = SqlDbType.VarChar;
                arrSqlParameter[4].Size = 200;
                arrSqlParameter[4].Value = objPokemon.descripcion;

                arrSqlParameter[5] = new SqlParameter();
                arrSqlParameter[5].ParameterName = "@IDTipo2";
                arrSqlParameter[5].SqlDbType = SqlDbType.Int;
                arrSqlParameter[5].Value = objPokemon.tipo2;

                arrSqlParameter[6] = new SqlParameter();
                arrSqlParameter[6].ParameterName = "@Imagen";
                arrSqlParameter[6].SqlDbType = SqlDbType.VarChar;
                arrSqlParameter[6].Size = 150;
                arrSqlParameter[6].Value = objPokemon.imagen;

                arrSqlParameter[7] = new SqlParameter();
                arrSqlParameter[7].ParameterName = "@altura";
                arrSqlParameter[7].SqlDbType = SqlDbType.Decimal;
                arrSqlParameter[7].Precision =4;
                arrSqlParameter[7].Value = objPokemon.altura;
				
				arrSqlParameter[8] = new SqlParameter();
                arrSqlParameter[8].ParameterName = "@peso";
                arrSqlParameter[8].SqlDbType = SqlDbType.Decimal;
                arrSqlParameter[8].Precision =4;
                arrSqlParameter[8].Value = objPokemon.peso;

                Cmd.Parameters.AddRange(arrSqlParameter);
                Con.Open();
                Cmd.ExecuteNonQuery();
                Con.Close();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		
		 public bool PokemonEliminar(int cod)
        {
            try
            {
                String strCadenaConexion = "server=DESKTOP-QCCGD0O\\SQLEXPRESS01; database=POKEDEX; Integrated Security=true;";
                SqlConnection Con = new SqlConnection(strCadenaConexion);
                String strSP = "uspPokemonEliminar";
                SqlCommand Cmd = new SqlCommand(strSP, Con);
                Cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter arrSqlParameter = new SqlParameter();

                arrSqlParameter.ParameterName = "@codigo";
                arrSqlParameter.SqlDbType = SqlDbType.Int;
                arrSqlParameter.Value = cod;

                Cmd.Parameters.Add(arrSqlParameter);
                Con.Open();
                Cmd.ExecuteNonQuery();
                Con.Close();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
