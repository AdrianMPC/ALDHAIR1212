using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POKEMON.BL.BE;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace POKEMON.DL.DALC
{
    public class TipoDALC
    {
		public List<TipoBE> TipoListar()
        {

            try
            {
				string strCadenaConexion = "server=DESKTOP-QCCGD0O\\SQLEXPRESS01; database=POKEDEX; Integrated Security=true;";
                SqlConnection Con = new SqlConnection(strCadenaConexion);
                String strSP = "uspTipoListar";
                SqlCommand Cmd = new SqlCommand(strSP, Con);
                Cmd.CommandType = System.Data.CommandType.StoredProcedure;
                List<TipoBE> lstTipoBE = new List<TipoBE>();

                Con.Open();
                SqlDataReader reader = Cmd.ExecuteReader();
                while (reader.Read())
                {
                    TipoBE objTipoBE = new TipoBE();
                    objTipoBE.Tipoid = Convert.ToInt32(reader[0]);
                    objTipoBE.tiponom = reader[1].ToString();

                    lstTipoBE.Add(objTipoBE);
                }
                reader.Close();
                Con.Close();

                return lstTipoBE;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public TipoBE TipoObtener(int cod)
        {
            try
            {
				string strCadenaConexion = "server=DESKTOP-QCCGD0O\\SQLEXPRESS01; database=POKEDEX; Integrated Security=true;";
                SqlConnection Con = new SqlConnection(strCadenaConexion);
                String strSP = "uspTipoObtener";
                SqlCommand Cmd = new SqlCommand(strSP, Con);
                Cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter arrSqlParameter = new SqlParameter();

                arrSqlParameter.ParameterName = "@tipoid";
                arrSqlParameter.SqlDbType = SqlDbType.Int;
                arrSqlParameter.Value = cod;

                TipoBE lstTipoBE = new TipoBE();
                Con.Open();
                Cmd.Parameters.Add(arrSqlParameter);
                Cmd.ExecuteNonQuery();

                SqlDataReader reader = Cmd.ExecuteReader();
                while (reader.Read())
                {
                    lstTipoBE.Tipoid = Convert.ToInt32(reader[0]);
                    lstTipoBE.tiponom = reader[1].ToString();
                }
                reader.Close();
                Con.Close();
				
                return lstTipoBE;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		
	}
}