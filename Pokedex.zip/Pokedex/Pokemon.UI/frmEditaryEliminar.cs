﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POKEMON.BL.BE;
using POKEMON.BL.BC;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Authentication.ExtendedProtection;
using System.Reflection.Emit;

namespace Pokemon.UI
{
    public partial class frmEditaryEliminar : Form
    {
        public int? userid { get; set; }
        public bool flag { get; set; }

        public frmEditaryEliminar()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void frmEditaryEliminar_Load(object sender, EventArgs e)
        {
            label1.Text = "Cree el pokemon";
            ed_but.Text = "Crear";
            ELI_BUT.Visible = false;
            TipoBC listartipo = new TipoBC();
            comboBox1.DataSource = listartipo.TipoListar();
            comboBox1.ValueMember = "Tipoid";
            comboBox1.DisplayMember = "tiponom";
            comboBox2.DataSource = listartipo.TipoListar();
            comboBox2.ValueMember = "Tipoid";
            comboBox2.DisplayMember = "tiponom";


            flag = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            TipoBC listartipo = new TipoBC();
            comboBox1.DataSource = listartipo.TipoListar();
            comboBox1.ValueMember = "Tipoid";
            comboBox1.DisplayMember = "tiponom";
            comboBox2.DataSource = listartipo.TipoListar();
            comboBox2.ValueMember = "Tipoid";
            comboBox2.DisplayMember = "tiponom";

            //EDITAR
            label1.Text = "Edita el pokemon";
            ed_but.Text = "Editar";
            ELI_BUT.Visible = true;
            PokemonBE poke = new PokemonBE();
            PokemonBC pokebc = new PokemonBC();
            poke = pokebc.PokemonObtener(Convert.ToInt32(numericUpDown1.Value));
            numPoke.Value = poke.cod;
            comboBox1.SelectedValue = poke.tipo1;
            comboBox2.SelectedValue = poke.tipo2;
            code_text.Text = poke.cod.ToString();
            nombre_text.Text = poke.nombre;
            desc_text.Text = poke.descripcion;
            image.Text = poke.imagen;
            altura_text.Text = poke.altura.ToString();
            peso_text.Text = poke.peso.ToString();
            pictureBox1.ImageLocation = image.Text;
            flag = true;
        }

        private void ed_but_Click(object sender, EventArgs e)
        {
            if (flag)
            {
                PokemonBE poke = new PokemonBE();
                PokemonBC pokebc = new PokemonBC();
                poke.pokemonID = Convert.ToInt32(numericUpDown1.Value);
                poke.cod = Convert.ToInt32(code_text.Text);
                poke.nombre = nombre_text.Text;
                poke.tipo1 = Convert.ToInt32(comboBox1.SelectedValue);
                poke.tipo2 = Convert.ToInt32(comboBox2.SelectedValue);
                poke.descripcion = desc_text.Text;
                poke.imagen = image.Text;
                poke.altura = Convert.ToDecimal(altura_text.Text);
                poke.peso = Convert.ToDecimal(peso_text.Text);
                if (pokebc.PokemonEditar(poke))
                {
                    MessageBox.Show("POKEMON EDITADO!");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("POKEMON NO EDITADO!");
                    this.Close();
                }
            }
            else
            {
                PokemonBE poke = new PokemonBE();
                PokemonBC pokebc = new PokemonBC();
                poke.pokemonID = Convert.ToInt32(code_text.Text);
                poke.cod = Convert.ToInt32(numPoke.Value);
                poke.nombre = nombre_text.Text;
                poke.tipo1 = Convert.ToInt32(comboBox1.SelectedValue);
                poke.tipo2 = Convert.ToInt32(comboBox2.SelectedValue);
                poke.descripcion = desc_text.Text;
                poke.imagen = image.Text;
                poke.altura = Convert.ToDecimal(altura_text.Text);
                poke.peso = Convert.ToDecimal(peso_text.Text);
                if (pokebc.PokemonInsertar(poke))
                {
                    MessageBox.Show("POKEMON AGREGADO!");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("POKEMON NO AGREGADO!");
                    this.Close();
                }
            }
        }
        private void ELI_BUT_Click(object sender, EventArgs e)
        {
            PokemonBC pokebc = new PokemonBC();
            if (pokebc.PokemonEliminar(Convert.ToInt32(numericUpDown1.Value)))
            {
                MessageBox.Show("POKEMON BORRADO!");
                this.Close();
            }
            else
            {
                MessageBox.Show("POKEMON NO BORRADO!");
                this.Close();
            }


        }

        private void can_but_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.ImageLocation = image.Text;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void nombre_text_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
