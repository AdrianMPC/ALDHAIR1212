﻿namespace Pokemon.UI
{
    partial class frmEditaryEliminar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            numericUpDown1 = new NumericUpDown();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            pokename = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label10 = new Label();
            label11 = new Label();
            code_text = new TextBox();
            nombre_text = new TextBox();
            desc_text = new TextBox();
            altura_text = new TextBox();
            peso_text = new TextBox();
            image = new TextBox();
            button2 = new Button();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            ed_but = new Button();
            can_but = new Button();
            ELI_BUT = new Button();
            label4 = new Label();
            numPoke = new NumericUpDown();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numPoke).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Showcard Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(343, 30);
            label1.Name = "label1";
            label1.Size = new Size(99, 30);
            label1.TabIndex = 0;
            label1.Text = "label1";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Subheading", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(323, 82);
            label2.Name = "label2";
            label2.Size = new Size(34, 21);
            label2.TabIndex = 1;
            label2.Text = "ID: ";
            label2.Click += label2_Click;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Cursor = Cursors.IBeam;
            numericUpDown1.Location = new Point(363, 82);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(189, 23);
            numericUpDown1.TabIndex = 2;
            // 
            // button1
            // 
            button1.BackgroundImage = Properties.Resources._1f7e1;
            button1.BackgroundImageLayout = ImageLayout.Stretch;
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Location = new Point(343, 124);
            button1.Name = "button1";
            button1.Size = new Size(99, 39);
            button1.TabIndex = 3;
            button1.Text = "BUSCAR";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(537, 178);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(254, 264);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(40, 301);
            label3.Name = "label3";
            label3.Size = new Size(72, 15);
            label3.TabIndex = 5;
            label3.Text = "Descripcion:";
            // 
            // pokename
            // 
            pokename.AutoSize = true;
            pokename.Location = new Point(40, 216);
            pokename.Name = "pokename";
            pokename.Size = new Size(54, 15);
            pokename.TabIndex = 6;
            pokename.Text = "Nombre:";
            pokename.TextAlign = ContentAlignment.TopCenter;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(40, 188);
            label5.Name = "label5";
            label5.Size = new Size(38, 15);
            label5.TabIndex = 7;
            label5.Text = "Code:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(40, 242);
            label6.Name = "label6";
            label6.Size = new Size(39, 15);
            label6.TabIndex = 8;
            label6.Text = "Tipo1:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(40, 271);
            label7.Name = "label7";
            label7.Size = new Size(39, 15);
            label7.TabIndex = 9;
            label7.Text = "Tipo2:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(41, 328);
            label8.Name = "label8";
            label8.Size = new Size(40, 15);
            label8.TabIndex = 10;
            label8.Text = "altura:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(537, 148);
            label10.Name = "label10";
            label10.Size = new Size(50, 15);
            label10.TabIndex = 12;
            label10.Text = "Imagen:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(40, 355);
            label11.Name = "label11";
            label11.Size = new Size(35, 15);
            label11.TabIndex = 13;
            label11.Text = "Peso:";
            // 
            // code_text
            // 
            code_text.Cursor = Cursors.IBeam;
            code_text.Location = new Point(118, 185);
            code_text.Name = "code_text";
            code_text.Size = new Size(100, 23);
            code_text.TabIndex = 14;
            // 
            // nombre_text
            // 
            nombre_text.Cursor = Cursors.IBeam;
            nombre_text.Location = new Point(118, 216);
            nombre_text.Name = "nombre_text";
            nombre_text.Size = new Size(100, 23);
            nombre_text.TabIndex = 15;
            nombre_text.TextChanged += nombre_text_TextChanged;
            // 
            // desc_text
            // 
            desc_text.Cursor = Cursors.IBeam;
            desc_text.Location = new Point(118, 301);
            desc_text.Name = "desc_text";
            desc_text.Size = new Size(214, 23);
            desc_text.TabIndex = 18;
            // 
            // altura_text
            // 
            altura_text.Cursor = Cursors.IBeam;
            altura_text.Location = new Point(118, 330);
            altura_text.Name = "altura_text";
            altura_text.Size = new Size(100, 23);
            altura_text.TabIndex = 19;
            // 
            // peso_text
            // 
            peso_text.Cursor = Cursors.IBeam;
            peso_text.Location = new Point(118, 355);
            peso_text.Name = "peso_text";
            peso_text.Size = new Size(100, 23);
            peso_text.TabIndex = 20;
            // 
            // image
            // 
            image.Cursor = Cursors.IBeam;
            image.Location = new Point(593, 145);
            image.Name = "image";
            image.Size = new Size(198, 23);
            image.TabIndex = 21;
            // 
            // button2
            // 
            button2.BackgroundImage = Properties.Resources._1f7e1;
            button2.BackgroundImageLayout = ImageLayout.Stretch;
            button2.Cursor = Cursors.Hand;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Location = new Point(593, 116);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 22;
            button2.Text = "Ver";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // comboBox1
            // 
            comboBox1.Cursor = Cursors.IBeam;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(118, 242);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 23;
            // 
            // comboBox2
            // 
            comboBox2.Cursor = Cursors.IBeam;
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(118, 271);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(121, 23);
            comboBox2.TabIndex = 24;
            // 
            // ed_but
            // 
            ed_but.BackgroundImage = Properties.Resources._1f7e1;
            ed_but.BackgroundImageLayout = ImageLayout.Stretch;
            ed_but.Cursor = Cursors.Hand;
            ed_but.FlatAppearance.BorderSize = 0;
            ed_but.FlatStyle = FlatStyle.Flat;
            ed_but.Location = new Point(343, 419);
            ed_but.Name = "ed_but";
            ed_but.Size = new Size(75, 23);
            ed_but.TabIndex = 25;
            ed_but.Text = "Editar";
            ed_but.UseVisualStyleBackColor = true;
            ed_but.Click += ed_but_Click;
            // 
            // can_but
            // 
            can_but.BackgroundImage = Properties.Resources._1f7e1;
            can_but.BackgroundImageLayout = ImageLayout.Stretch;
            can_but.Cursor = Cursors.Hand;
            can_but.FlatAppearance.BorderSize = 0;
            can_but.FlatStyle = FlatStyle.Flat;
            can_but.Location = new Point(429, 419);
            can_but.Name = "can_but";
            can_but.Size = new Size(75, 23);
            can_but.TabIndex = 26;
            can_but.Text = "Atras";
            can_but.UseVisualStyleBackColor = true;
            can_but.Click += can_but_Click;
            // 
            // ELI_BUT
            // 
            ELI_BUT.BackgroundImage = Properties.Resources._1f7e1;
            ELI_BUT.BackgroundImageLayout = ImageLayout.Stretch;
            ELI_BUT.Cursor = Cursors.Hand;
            ELI_BUT.FlatAppearance.BorderSize = 0;
            ELI_BUT.FlatStyle = FlatStyle.Flat;
            ELI_BUT.Location = new Point(52, 419);
            ELI_BUT.Name = "ELI_BUT";
            ELI_BUT.Size = new Size(75, 23);
            ELI_BUT.TabIndex = 27;
            ELI_BUT.Text = "Eliminar";
            ELI_BUT.UseVisualStyleBackColor = true;
            ELI_BUT.Click += ELI_BUT_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(41, 153);
            label4.Name = "label4";
            label4.Size = new Size(118, 15);
            label4.TabIndex = 28;
            label4.Text = "Número de Pokedex:";
            // 
            // numPoke
            // 
            numPoke.BackColor = Color.White;
            numPoke.Cursor = Cursors.IBeam;
            numPoke.Location = new Point(165, 151);
            numPoke.Name = "numPoke";
            numPoke.Size = new Size(120, 23);
            numPoke.TabIndex = 29;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Profesor_Oak__XY_;
            pictureBox2.Location = new Point(354, 185);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(150, 205);
            pictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox2.TabIndex = 30;
            pictureBox2.TabStop = false;
            // 
            // frmEditaryEliminar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 192);
            ClientSize = new Size(813, 471);
            Controls.Add(pictureBox2);
            Controls.Add(numPoke);
            Controls.Add(label4);
            Controls.Add(ELI_BUT);
            Controls.Add(can_but);
            Controls.Add(ed_but);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(button2);
            Controls.Add(image);
            Controls.Add(peso_text);
            Controls.Add(altura_text);
            Controls.Add(desc_text);
            Controls.Add(nombre_text);
            Controls.Add(code_text);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(pokename);
            Controls.Add(label3);
            Controls.Add(pictureBox1);
            Controls.Add(button1);
            Controls.Add(numericUpDown1);
            Controls.Add(label2);
            Controls.Add(label1);
            ForeColor = Color.Black;
            Name = "frmEditaryEliminar";
            Load += frmEditaryEliminar_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numPoke).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private NumericUpDown numericUpDown1;
        private Button button1;
        private PictureBox pictureBox1;
        private Label label3;
        private Label pokename;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label10;
        private Label label11;
        private TextBox code_text;
        private TextBox nombre_text;
        private TextBox desc_text;
        private TextBox altura_text;
        private TextBox peso_text;
        private TextBox image;
        private Button button2;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private Button ed_but;
        private Button can_but;
        private Button ELI_BUT;
        private Label label4;
        private NumericUpDown numPoke;
        private PictureBox pictureBox2;
    }
}