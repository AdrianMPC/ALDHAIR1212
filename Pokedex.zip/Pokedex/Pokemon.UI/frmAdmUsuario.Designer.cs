﻿namespace Pokemon.UI
{
    partial class frmAdmUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvPokemon = new DataGridView();
            ed_but = new Button();
            act_but = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dgvPokemon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dgvPokemon
            // 
            dgvPokemon.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPokemon.Location = new Point(12, 122);
            dgvPokemon.Name = "dgvPokemon";
            dgvPokemon.RowHeadersWidth = 51;
            dgvPokemon.RowTemplate.Height = 25;
            dgvPokemon.Size = new Size(601, 268);
            dgvPokemon.TabIndex = 0;
            // 
            // ed_but
            // 
            ed_but.BackgroundImage = Properties.Resources.circulo;
            ed_but.BackgroundImageLayout = ImageLayout.Stretch;
            ed_but.Cursor = Cursors.Hand;
            ed_but.FlatStyle = FlatStyle.Flat;
            ed_but.ForeColor = Color.White;
            ed_but.Location = new Point(12, 396);
            ed_but.Name = "ed_but";
            ed_but.Size = new Size(171, 23);
            ed_but.TabIndex = 1;
            ed_but.Text = "Nuevo o detalles";
            ed_but.UseVisualStyleBackColor = true;
            ed_but.Click += ed_but_Click;
            // 
            // act_but
            // 
            act_but.BackgroundImage = Properties.Resources.circulo;
            act_but.BackgroundImageLayout = ImageLayout.Stretch;
            act_but.Cursor = Cursors.Hand;
            act_but.FlatAppearance.BorderSize = 0;
            act_but.FlatStyle = FlatStyle.Flat;
            act_but.ForeColor = Color.White;
            act_but.Location = new Point(534, 396);
            act_but.Name = "act_but";
            act_but.Size = new Size(79, 23);
            act_but.TabIndex = 2;
            act_but.Text = "Actualizar";
            act_but.UseVisualStyleBackColor = true;
            act_but.Click += act_but_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Pokemon;
            pictureBox1.Location = new Point(161, 9);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(300, 108);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // frmAdmUsuario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 224, 192);
            ClientSize = new Size(625, 431);
            Controls.Add(pictureBox1);
            Controls.Add(act_but);
            Controls.Add(ed_but);
            Controls.Add(dgvPokemon);
            Name = "frmAdmUsuario";
            Text = "BIENVENIDO";
            Load += frmAdmUsuario_Load_1;
            ((System.ComponentModel.ISupportInitialize)dgvPokemon).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvPokemon;
        private Button ed_but;
        private Button act_but;
        private PictureBox pictureBox1;
    }
}