﻿using POKEMON.BL.BC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pokemon.UI
{
    public partial class frmAdmUsuario : Form
    {
        public frmAdmUsuario()
        {
            InitializeComponent();
        }

        private void frmAdmUsuario_Load(object sender, EventArgs e)
        {
            PokemonBC objPokemon = new PokemonBC();
            dgvPokemon.DataSource = objPokemon.PokemonListar();
        }

        private void frmAdmUsuario_Load_1(object sender, EventArgs e)
        {
            PokemonBC objPokemon = new PokemonBC();
            dgvPokemon.DataSource = objPokemon.PokemonListar();
        }

        private void ed_but_Click(object sender, EventArgs e)
        {
            frmEditaryEliminar frmEdit = new frmEditaryEliminar();
            frmEdit.ShowDialog();
        }

        private void act_but_Click(object sender, EventArgs e)
        {
            PokemonBC objPokemon = new PokemonBC();
            dgvPokemon.DataSource = objPokemon.PokemonListar();
        }
    }
}
