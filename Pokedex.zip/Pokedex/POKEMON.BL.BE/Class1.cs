﻿namespace POKEMON.BL.BE
{
    public class Class1
    {

    }
}