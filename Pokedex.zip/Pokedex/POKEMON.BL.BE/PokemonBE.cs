﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POKEMON.BL.BE
{
    public class PokemonBE
    {
        public int pokemonID { get; set; }
        public int cod { get; set; }
        public String nombre { get; set; }
        public int tipo1 { get; set; }
        public int tipo2 { get; set; } 
        public String descripcion { get; set; }
        public String imagen { get; set; }
        public Decimal altura { get; set; }
        public Decimal peso { get; set; }

    }
}   
