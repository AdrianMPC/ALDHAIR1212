﻿namespace POKEMON.BL.BE
{
    public class TipoBE
    {
        public int Tipoid { get; set; }
        public String tiponom { get; set; }
    }
}   
