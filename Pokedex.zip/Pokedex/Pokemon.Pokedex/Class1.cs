﻿namespace Pokemon.Pokedex
{
    public class Class1
    {

    }
}