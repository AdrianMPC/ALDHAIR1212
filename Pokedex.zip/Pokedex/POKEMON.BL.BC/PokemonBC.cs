﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POKEMON.BL.BE;
using POKEMON.DL.DALC;
namespace POKEMON.BL.BC
{
    public class PokemonBC
    {
        public List<PokemonBE> PokemonListar()
        {
            try
            {
                PokemonDALC objPokemon = new PokemonDALC();
                return objPokemon.PokemonListar();
            }
            catch (Exception ex) 
            {
				// Atrapar el error
                return new List<PokemonBE>();
            }

        }
		   
		public PokemonBE PokemonObtener(int cod)
        {
            try
            {
                PokemonDALC objPokemon = new PokemonDALC();
                return objPokemon.PokemonObtener(cod);
            }
            catch (Exception ex)
            {
				// Atrapar el error
                return new PokemonBE();
            }

        }

        public bool PokemonEliminar(int Cod)
        {
            try
            {
                PokemonDALC objPokemon = new PokemonDALC();
                return objPokemon.PokemonEliminar(Cod);
            }
            catch (Exception ex)
            {
				// Atrapar el error
                return false;
            }
        }

        public bool PokemonEditar(PokemonBE objPokemonBE)
        {
            try
            {
                PokemonDALC objPokemon = new PokemonDALC();
                return objPokemon.PokemonEditar(objPokemonBE);
            }
            catch (Exception ex)
            {
				// Atrapar el error
                return false;
            }
        }

        public bool PokemonInsertar(PokemonBE objPokemonBE)
        {
            try
            {
                PokemonDALC objPokemon = new PokemonDALC();
                return objPokemon.AgregarPokemon(objPokemonBE);
            }
            catch (Exception ex)
            {
				// Atrapar el error
                return false;
            }
        }
    }
}
