﻿namespace POKEMON.BL.BC
{
    public class Class1
    {

    }
}