using POKEMON.BL.BE;
using POKEMON.DL.DALC;


namespace POKEMON.BL.BC
{
    public class TipoBC
    {
		public List<TipoBE> TipoListar()
		{
			try
            {
                TipoDALC objTipoDALC = new TipoDALC();
                return objTipoDALC.TipoListar();
            }
            catch (Exception ex) 
            {
				// Atrapar el error
                return new List<TipoBE>();
            }
		}	
		
		public TipoBE TipoObtener(int cod)
		{
			try
            {
                TipoDALC objTipoDALC = new TipoDALC();
                return objTipoDALC.TipoObtener(cod);
            }
            catch (Exception ex) 
            {
				// Atrapar el error
                return new TipoBE();
            }
		}	
	}
}